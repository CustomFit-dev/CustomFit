__author__ = "Inada Naoki <songofacandy@gmail.com>"
__version__ = "2.2.5"
version_info = (2, 2, 5, "final", 0)
